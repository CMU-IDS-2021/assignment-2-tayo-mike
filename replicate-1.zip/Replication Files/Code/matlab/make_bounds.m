% make_bounds
clear
n = 100;

absmob_resultsdir = ''; % Rename filepath to the results folder


absmob_matlab = strcat(absmob_resultsdir,'/matlab/');
mkdir(absmob_matlab);

infile = strcat(absmob_resultsdir,'/Baseline/marginals_baseline.txt');
X = dlmread(infile); 
percentile = X(:,1);
kid = X(:,2);
cohort = X(:,3);
par = X(:,4);

outfile = strcat(absmob_matlab,'marginals.mat');
save(outfile)

load(outfile)
est_min_all = zeros(n^2,1);
est_max_all = zeros(n^2,1);
abs_min = zeros(1984-1940+1,1);
abs_max = zeros(1984-1940+1,1);
cohort_count = 1;
fosd = 0 ;

for c = 1940:1984
    load(outfile)
    par_marginal = par(cohort(:,1)==c,1);
    kid_marginal = kid(cohort(:,1)==c,1);
    maxminv100
    abs_min(cohort_count,1)= est_min_val;
    abs_max(cohort_count,1)= est_max_val;
    est_min_all = [est_min_all , est_min];
    est_max_all = [est_max_all , est_max];
    cohort_count = cohort_count + 1
end
out_all = [abs_min,abs_max];


load(outfile)
est_min_all = zeros(n^2,1);
est_max_all = zeros(n^2,1);
abs_min = zeros(1984-1940+1,1);
abs_max = zeros(1984-1940+1,1);
cohort_count = 1;
fosd = 1 ;
for c = 1940:1984
    load(outfile)
    par_marginal = par(cohort(:,1)==c,1);
    kid_marginal = kid(cohort(:,1)==c,1);
    maxminv100
    abs_min(cohort_count,1)= est_min_val;
    abs_max(cohort_count,1)= est_max_val;
    est_min_all = [est_min_all , est_min];
    est_max_all = [est_max_all , est_max];
    cohort_count = cohort_count + 1
end
out_fosd = [abs_min,abs_max];

cohort = [1940:1984]';
out = [cohort, out_fosd , out_all];

cd(absmob_matlab)
save out.txt out -ascii -tabs

figure(1)
plot(1940:1984,out_all)

figure(2)
plot(1940:1984,out_fosd)

%% Export maximizing and minimizing copulas 


cop1940_min = zeros(n,n);
for pp = 1:n
    for kk = 1:n
    cop1940_min(kk,pp) = est_min_all(kk + (pp-1)*n,2);
    end
end
save cop1940_min.txt cop1940_min -ascii -tabs


cop1940_max = zeros(n,n);
for pp = 1:n
    for kk = 1:n
    cop1940_max(kk,pp) = est_max_all(kk + (pp-1)*n,2);
    end
end
save cop1940_max.txt cop1940_max -ascii -tabs

cop1980_min = zeros(n,n);
for pp = 1:n
    for kk = 1:n
    cop1980_min(kk,pp) = est_min_all(kk + (pp-1)*n,end-4);
    end
end
save cop1980_min.txt cop1980_min -ascii -tabs

cop1980_max = zeros(n,n);
for pp = 1:n
    for kk = 1:n
    cop1980_max(kk,pp) = est_max_all(kk + (pp-1)*n,end-4);
    end
end
save cop1980_max.txt cop1980_max -ascii -tabs

cop1984_min = zeros(n,n);
for pp = 1:n
    for kk = 1:n
    cop1984_min(kk,pp) = est_min_all(kk + (pp-1)*n,end);
    end
end
save cop1984_min.txt cop1984_min -ascii -tabs

cop1984_max = zeros(n,n);
for pp = 1:n
    for kk = 1:n
    cop1984_max(kk,pp) = est_max_all(kk + (pp-1)*n,end);
    end
end
save cop1984_max.txt cop1984_max -ascii -tabs



