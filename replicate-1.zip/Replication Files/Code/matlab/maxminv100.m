% Find max and min of absolute mobility across copulas

% input: par_marginal and kid_marginal
% output: est_max_val, est_min_val are max and min absolute mobility;
% est_max and est_min are the corresponding copulas


%% Make f
n = 100;

above = zeros(n*n,1);
for pp = 1:n
    for kk = 1:n
    above(kk+(pp-1)*n,1) = (par_marginal(pp)<kid_marginal(kk));
    end
end

%% Stochastic Ordering Requirements 
Aineq = []
bineq = []

% Impose FOSD
if fosd == 1 
cdfer = zeros(n^2,n^2);
for pp = 1:n 
    for kk = 1:n 
        for kkcdf = 1:kk
            cdfer(kk+(pp-1)*n,kkcdf+(pp-1)*n) = 1 ;
        end
    end
end

differ = zeros(n*(n-1),n^2);
for pp = 1:n-1
    for kk = 1:n 
            differ(kk+(pp-1)*n,kk+(pp-1)*n) = -1 ;
            differ(kk+(pp-1)*n,kk+(pp)*n) = 1 ;
    end
end

Aineq = differ * cdfer ;
bineq = zeros(n*(n-1),1);

lb = .001*ones(n^2,1);
end



%% Test Copula 

c = ones(n*n,1)/(n*n);

above' * c


%% Constraints

% n = 100 constraints:

Aeq1 = zeros(100,100*100);
for j = 1:100 
    temp = [];
    for k = 1:100
        if j == k 
            temp = [temp , ones(1,n)];
        elseif j ~= k 
            temp = [temp , zeros(1,n)];
        end
    end
    Aeq1(j,:) = temp;    
end

Aeq2 = zeros(100,100*100);
for j = 1:100 
    temp = zeros(1,100);
    temp2 = [];
    for k = 1:100
        temp(k) = (j == k); 
    end
    for k = 1:100
        temp2 = [temp2,temp];
    end
    Aeq2(j,:) = temp2; 
end

Aeq = [Aeq1 ; Aeq2];
beq = (1/n)*ones(2*n,1);

lb = zeros(n^2,1);
ub = ones(n^2,1);

% First order stochastic dominance




%% Copula maximization 

if fosd == 0
    para_start = ones(n^2,1)/(n^2);
    options = optimoptions('linprog','Algorithm','dual-simplex');
    [est_min,est_min_val] = linprog(above,[],[],Aeq,beq,lb,ub,para_start,options)
    [est_max,est_max_val] = linprog(-above,[],[],Aeq,beq,lb,ub,para_start,options)
    est_max_val = -est_max_val;
end

if fosd == 1 
    para_start = ones(n^2,1)/(n^2);
    options = optimoptions('linprog','Algorithm','dual-simplex');
    [est_min,est_min_val] = linprog(above,Aineq,bineq,Aeq,beq,lb,ub,para_start,options)
    [est_max,est_max_val] = linprog(-above,Aineq,bineq,Aeq,beq,lb,ub,para_start,options)
    est_max_val = -est_max_val;
end



